<?php
namespace Module\Frontend\Controllers; 



class ErrorController extends ControllerBase
{
    public function indexAction()
    {
    }
}