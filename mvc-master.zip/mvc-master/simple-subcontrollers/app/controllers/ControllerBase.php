<?php

namespace MyApp\Controllers;

use Phalcon\Mvc\Controller;

class ControllerBase extends Controller
{

}