<?php

namespace Multiple\Backend\Models;

class Products extends \Phalcon\Mvc\Model
{

	public function getSource()
	{
		return 'products';
	}

}