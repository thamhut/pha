<?php

class ControllerBase extends \Phalcon\Mvc\Controller
{

}