<?php

namespace Single\Controllers;

class IndexController extends \Phalcon\Mvc\Controller {

	public function indexAction(){
		
	}
	
}