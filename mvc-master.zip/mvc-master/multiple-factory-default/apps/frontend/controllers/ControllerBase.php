<?php

namespace Modules\Frontend\Controllers;

class ControllerBase extends \Phalcon\Mvc\Controller
{

}